from bs4 import BeautifulSoup
import csv

for number in range(2005, 2015):
    doneonce = False
    filestr = 'sources/' + str(number) + '.html'
    soup = BeautifulSoup(open(filestr), 'lxml')

    t = soup.select('table tr')
    outputstr = 'outputs/' + str(number) + '.csv'
    with open (outputstr, 'wb') as f:
        writer = csv.writer(f)
        for tr in t:
            newRow = []
            for td in tr:
                for child in td:
                    try:
                        print child.get_text()
                        newRow.append(child.get_text().encode('ascii', 'ignore'))
                    except AttributeError:
                        print child
                        newRow.append(child.encode('ascii', 'ignore'))
            for e in newRow:
                if e == '\n':
                    newRow.remove(e)
            print newRow
            if (newRow[0] == 'Team') & (doneonce == False):
                writer.writerow(newRow)
                doneonce = True
            elif newRow[0] != 'Team':
                writer.writerow(newRow)